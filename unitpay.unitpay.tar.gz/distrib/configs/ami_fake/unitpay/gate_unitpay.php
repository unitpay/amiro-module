<?php
chdir(realpath('../'));
require_once 'cm_ini.php';
require_once $GLOBALS['LOCAL_FILES_PATH'] . 'eshop/pay_drivers/unitpay/gate_unitpay.php';